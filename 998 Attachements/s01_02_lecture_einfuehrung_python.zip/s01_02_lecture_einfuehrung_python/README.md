# s01_02 – Vorlesung

**Einführung in Python**

Mi 16.09.2026, 12:50–15:10 · Raum S1A_431

## Zustand dieses Ordners

Die Notebooks sind **clean**: Markdown-Text vollständig, Code-Zellen leer.
Diese Fassung geht **vor** der Vorlesung auf ILIAS (Early Bird).

Während der Vorlesung füllen Sie die Code-Zellen hier direkt aus und laden
denselben Ordner **nach** der Vorlesung erneut hoch.

Die ausgefüllte Fassung des letzten Semesters liegt unter `../_backup_hs25/`
– als Rückfallebene, nicht zum Verteilen.

## Lernziele

- Begriff Algorithmus, Ablauf des Moduls, Arbeitsumgebung einrichten
- Variablen, Zuweisung, arithmetische Operatoren
- print- und input-Funktion, Triple-Quoted Strings
- Einfache Entscheidungen, dynamische Typisierung, min/max

## Notebooks

- `calculate_minimum.py`
- `ch02images`/
- `decisions.py`
- `lecture_01_agenda.ipynb`
- `lecture_02_variablen_und_zuweisung.ipynb`
- `lecture_03_arithmetische_operatoren.ipynb`
- `lecture_04_print_funktion.ipynb`
- `lecture_05_dreifach_anfuehrungszeichen.ipynb`
- `lecture_06_input_funktion.ipynb`
- `lecture_07_entscheidungen.ipynb`
- `lecture_08_objekte_und_dynamische_typisierung.ipynb`
- `lecture_09_min_und_max_funktion.ipynb`
