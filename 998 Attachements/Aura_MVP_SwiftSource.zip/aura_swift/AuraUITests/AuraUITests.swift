import XCTest

/// A minimal smoke test confirming the app launches and the core tabs
/// are reachable. Expand this per the QA checklist in Section 23 of the
/// build documentation (OAuth token refresh/expiry, empty/error states,
/// accessibility passes) as those flows are wired to a real backend.
final class AuraUITests: XCTestCase {

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    func testAppLaunches() throws {
        let app = XCUIApplication()
        app.launch()
        XCTAssertTrue(app.exists)
    }

    func testOnboardingGetStartedButtonExists() throws {
        let app = XCUIApplication()
        app.launch()
        // On first launch (no stored onboarding flag) the Welcome screen
        // should show its primary action.
        let getStarted = app.buttons["Get Started"]
        XCTAssertTrue(getStarted.waitForExistence(timeout: 3))
    }
}
