import SwiftUI

struct SettingsView: View {
    @State private var accounts: [ConnectedAccount] = [
        ConnectedAccount(provider: .gmail, lastSyncedAt: Date().addingTimeInterval(-120)),
        ConnectedAccount(provider: .icloudCalendar, lastSyncedAt: Date().addingTimeInterval(-120)),
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AuraSpacing.lg) {
                AuraCard {
                    SectionLabel(text: "Connected accounts")
                    ForEach(accounts) { account in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(account.provider.rawValue).font(AuraFont.bodyBold()).foregroundColor(AuraColor.ink)
                                Text("Synced 2 min ago").font(AuraFont.caption()).foregroundColor(AuraColor.slate)
                            }
                            Spacer()
                            Button("Disconnect") { disconnect(account) }
                                .font(AuraFont.caption())
                                .foregroundColor(AuraColor.slate)
                        }
                        .padding(.vertical, 6)
                        if account.id != accounts.last?.id { Divider() }
                    }
                }

                AuraCard {
                    SectionLabel(text: "Reply preferences")
                    settingsRow(title: "Tone", value: "Friendly & direct")
                    Divider()
                    settingsRow(title: "Signature", value: "On")
                }

                AuraCard {
                    SectionLabel(text: "Privacy & data")
                    settingsRow(title: "Activity log", value: "")
                    Divider()
                    settingsRow(title: "Delete my data", value: "")
                }
            }
            .padding(20)
        }
        .background(AuraColor.surfaceTint.ignoresSafeArea())
        .navigationTitle("Settings")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func settingsRow(title: String, value: String) -> some View {
        HStack {
            Text(title).font(AuraFont.bodyBold()).foregroundColor(AuraColor.ink)
            Spacer()
            if !value.isEmpty {
                Text(value).font(AuraFont.caption()).foregroundColor(AuraColor.slate)
            }
            Image(systemName: "chevron.right").font(.system(size: 12)).foregroundColor(Color(hex: "B4AFC7"))
        }
        .padding(.vertical, 6)
    }

    private func disconnect(_ account: ConnectedAccount) {
        accounts.removeAll { $0.id == account.id }
    }
}

#Preview {
    NavigationStack { SettingsView() }
}
