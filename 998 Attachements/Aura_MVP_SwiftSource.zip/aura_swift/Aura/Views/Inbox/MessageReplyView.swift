import SwiftUI

struct MessageReplyView: View {
    let message: EmailMessage
    @ObservedObject var viewModel: InboxViewModel

    @State private var isEditing = false
    @State private var editedText: String = ""
    @State private var selectedSlot: TimeSlotOption?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: AuraSpacing.md) {
                originalMessageCard
                if message.replyStatus == .drafted, let draft = message.draftedReply {
                    replyCard(draft: draft)
                } else if message.replyStatus == .sent {
                    sentConfirmation
                }
            }
            .padding(20)
        }
        .background(AuraColor.surfaceTint.ignoresSafeArea())
        .safeAreaInset(edge: .bottom) {
            if message.replyStatus == .drafted {
                actionBar
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { editedText = message.draftedReply ?? "" }
    }

    private var originalMessageCard: some View {
        AuraCard {
            Text(message.subject).font(AuraFont.bodyBold()).foregroundColor(AuraColor.ink)
            Text("\(message.senderName) · \(message.receivedAt.hourMinuteString)")
                .font(AuraFont.caption()).foregroundColor(AuraColor.slate)
            Divider().padding(.vertical, 4)
            Text(message.fullBody)
                .font(.system(size: 14))
                .foregroundColor(AuraColor.ink)
                .lineSpacing(4)
        }
    }

    private func replyCard(draft: String) -> some View {
        AuraSuggestionCard(label: "Aura suggests a reply") {
            if isEditing {
                TextEditor(text: $editedText)
                    .font(.system(size: 13.5))
                    .frame(minHeight: 100)
                    .scrollContentBackground(.hidden)
            } else {
                Text(editedText)
                    .font(.system(size: 13.5))
                    .foregroundColor(AuraColor.ink)
                    .lineSpacing(3)
            }

            if !message.proposedSlots.isEmpty {
                FlowChips(slots: message.proposedSlots, selected: $selectedSlot)
            }
        }
    }

    private var sentConfirmation: some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark.circle.fill").foregroundColor(AuraColor.success)
            Text("Reply sent").font(AuraFont.bodyBold()).foregroundColor(AuraColor.success)
        }
        .padding(.top, 4)
    }

    private var actionBar: some View {
        HStack(spacing: 10) {
            SecondaryButton(title: isEditing ? "Done" : "Edit") {
                isEditing.toggle()
            }
            PrimaryButton(title: "Send", isLoading: viewModel.isSending) {
                Task {
                    await viewModel.sendReply(for: message, editedText: editedText)
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 20)
        .background(AuraColor.surfaceTint)
    }
}

/// Simple wrapping chip row for proposed time slots.
private struct FlowChips: View {
    let slots: [TimeSlotOption]
    @Binding var selected: TimeSlotOption?

    var body: some View {
        // A basic wrapping layout using LazyVGrid keeps this dependency-free;
        // swap for SwiftUI's native Layout protocol if targeting iOS 16+.
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 90), spacing: 8)], alignment: .leading, spacing: 8) {
            ForEach(slots) { slot in
                TimeSlotChip(
                    title: slot.displayText,
                    isSelected: selected?.id == slot.id || (selected == nil && slot.isRecommended),
                    action: { selected = slot }
                )
            }
        }
        .padding(.top, 6)
    }
}

#Preview {
    NavigationStack {
        MessageReplyView(message: EmailMessage.sampleData[0], viewModel: InboxViewModel())
    }
}
