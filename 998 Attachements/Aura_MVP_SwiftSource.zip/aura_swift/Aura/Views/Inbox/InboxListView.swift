import SwiftUI

struct InboxListView: View {
    @StateObject private var viewModel = InboxViewModel()

    private var attentionCount: Int {
        viewModel.messages.filter { $0.replyStatus == .drafted || $0.detectedDeadline != nil }.count
    }

    var body: some View {
        NavigationStack {
            List {
                ForEach(viewModel.messages) { message in
                    NavigationLink(destination: MessageReplyView(message: message, viewModel: viewModel)) {
                        InboxRow(message: message)
                    }
                    .listRowInsets(EdgeInsets(top: 10, leading: 20, bottom: 10, trailing: 20))
                    .listRowSeparatorTint(AuraColor.cardBorder)
                }
            }
            .listStyle(.plain)
            .background(AuraColor.surfaceTint.ignoresSafeArea())
            .scrollContentBackground(.hidden)
            .navigationTitle("")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Inbox").font(AuraFont.title()).foregroundColor(AuraColor.ink)
                        Text(attentionCount > 0 ? "\(attentionCount) need your attention" : "You're all caught up")
                            .font(AuraFont.caption()).foregroundColor(AuraColor.slate)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: SettingsView()) {
                        Image(systemName: "gearshape.fill").foregroundColor(AuraColor.accent)
                    }
                }
            }
        }
        .task { await viewModel.load() }
    }
}

private struct InboxRow: View {
    let message: EmailMessage

    var body: some View {
        HStack(spacing: 12) {
            Circle().fill(AuraColor.suggestionBackground).frame(width: 38, height: 38)
                .overlay(Text(message.senderInitial).font(AuraFont.bodyBold()).foregroundColor(AuraColor.accent))

            VStack(alignment: .leading, spacing: 2) {
                Text(message.senderName).font(AuraFont.bodyBold()).foregroundColor(AuraColor.ink)
                Text(message.subject).font(AuraFont.caption()).foregroundColor(AuraColor.slate).lineLimit(1)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 6) {
                Text(message.receivedAt.hourMinuteString).font(.system(size: 11)).foregroundColor(AuraColor.slate)
                if message.replyStatus == .drafted {
                    StatusBadge(text: "Drafted", style: .neutral)
                } else if message.detectedDeadline != nil {
                    StatusBadge(text: "Deadline", style: .warning)
                }
            }
        }
    }
}

#Preview {
    InboxListView()
}
