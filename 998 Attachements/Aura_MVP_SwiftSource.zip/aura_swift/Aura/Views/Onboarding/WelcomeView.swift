import SwiftUI

struct WelcomeView: View {
    let onGetStarted: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            Spacer()

            VStack(spacing: 22) {
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .fill(LinearGradient(colors: [AuraColor.accent, AuraColor.accentLight], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 88, height: 88)
                    .overlay(Text("A").font(.system(size: 38, weight: .heavy)).foregroundColor(.white))

                Text("Aura")
                    .font(.system(size: 30, weight: .heavy))
                    .foregroundColor(AuraColor.ink)

                Text("Aura drafts your replies and tells you exactly when to wake up.")
                    .font(AuraFont.body())
                    .foregroundColor(AuraColor.slate)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 32)
            }

            Spacer()

            VStack(spacing: 10) {
                PrimaryButton(title: "Get Started", action: onGetStarted)
                TextLinkButton(title: "I already have an account", action: {})
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 40)
        }
    }
}

#Preview {
    WelcomeView(onGetStarted: {})
}
