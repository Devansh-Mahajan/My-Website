import SwiftUI

enum OnboardingStep {
    case welcome, connectMail, firstValue
}

/// Drives the three onboarding screens (Section 4 of the Illustrated
/// UI/UX Documentation) and flips `hasCompletedOnboarding` once the user
/// reaches the Today screen for the first time.
struct OnboardingContainerView: View {
    @AppStorage("hasCompletedOnboarding") private var hasCompletedOnboarding = false
    @State private var step: OnboardingStep = .welcome

    var body: some View {
        Group {
            switch step {
            case .welcome:
                WelcomeView(onGetStarted: { step = .connectMail })
            case .connectMail:
                ConnectMailView(
                    onConnected: { step = .firstValue },
                    onSkip: { step = .firstValue }
                )
            case .firstValue:
                FirstValueView(onContinue: { hasCompletedOnboarding = true })
            }
        }
        .background(AuraColor.surfaceTint.ignoresSafeArea())
    }
}
