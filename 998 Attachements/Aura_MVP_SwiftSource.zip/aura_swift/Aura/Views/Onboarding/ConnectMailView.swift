import SwiftUI

struct ConnectMailView: View {
    let onConnected: () -> Void
    let onSkip: () -> Void

    @State private var isConnecting = false

    var body: some View {
        VStack(alignment: .leading, spacing: AuraSpacing.lg) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Connect your mail")
                    .font(AuraFont.title())
                    .foregroundColor(AuraColor.ink)
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)

            VStack(alignment: .leading, spacing: 20) {
                AuraCard {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Aura reads new messages to draft replies and spot deadlines.")
                            .font(AuraFont.caption())
                            .foregroundColor(AuraColor.ink)
                        Text("Nothing is ever sent without your approval.")
                            .font(AuraFont.caption())
                            .foregroundColor(AuraColor.slate)
                    }
                }

                VStack(spacing: 12) {
                    providerRow(title: "Gmail", subtitle: "Connect with Google", initial: "G", bg: Color(hex: "FDEAEA"), fg: Color(hex: "D64545"))
                    providerRow(title: "Outlook / Microsoft", subtitle: "Connect with Microsoft", initial: "M", bg: Color(hex: "E9F1FB"), fg: Color(hex: "2B6FC9"))
                }
            }
            .padding(.horizontal, 20)

            Spacer()

            TextLinkButton(title: "Skip for now", action: onSkip)
                .frame(maxWidth: .infinity)
                .padding(.bottom, 32)
        }
    }

    private func providerRow(title: String, subtitle: String, initial: String, bg: Color, fg: Color) -> some View {
        Button {
            connect()
        } label: {
            AuraCard {
                HStack(spacing: 14) {
                    Circle().fill(bg).frame(width: 38, height: 38)
                        .overlay(Text(initial).font(AuraFont.bodyBold()).foregroundColor(fg))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(title).font(AuraFont.bodyBold()).foregroundColor(AuraColor.ink)
                        Text(subtitle).font(AuraFont.caption()).foregroundColor(AuraColor.slate)
                    }
                    Spacer()
                    Image(systemName: "chevron.right").foregroundColor(Color(hex: "B4AFC7"))
                }
            }
        }
        .buttonStyle(.plain)
    }

    private func connect() {
        // Real implementation: open ASWebAuthenticationSession for the
        // provider's OAuth flow (see Section 17, Integration Guide: Mail).
        isConnecting = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            isConnecting = false
            onConnected()
        }
    }
}

#Preview {
    ConnectMailView(onConnected: {}, onSkip: {})
}
