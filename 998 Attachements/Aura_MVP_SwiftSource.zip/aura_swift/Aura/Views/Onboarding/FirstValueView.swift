import SwiftUI

/// The most important screen in onboarding: proves Aura's value inside
/// the first minute using the (mocked, for MVP demo purposes) real
/// connected-account data rather than a sample/demo state.
struct FirstValueView: View {
    let onContinue: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: AuraSpacing.lg) {
            VStack(alignment: .leading, spacing: 4) {
                Text("You're all set").font(AuraFont.title()).foregroundColor(AuraColor.ink)
                Text("Here's what Aura found already").font(AuraFont.caption()).foregroundColor(AuraColor.slate)
            }
            .padding(.horizontal, 20)
            .padding(.top, 12)

            VStack(spacing: 16) {
                AuraSuggestionCard {
                    Text("Reply to **Benni** about the workshop prep — I found 3 open slots this week.")
                        .font(AuraFont.caption())
                        .foregroundColor(AuraColor.ink)
                    HStack(spacing: 8) {
                        TimeSlotChip(title: "Tue 14:00", action: {})
                        TimeSlotChip(title: "Wed 10:00", action: {})
                        TimeSlotChip(title: "Wed 15:30", action: {})
                    }
                }

                AuraCard {
                    SectionLabel(text: "Tomorrow's wake-up")
                    Text(Date.at(7, 10).shortTimeString)
                        .font(AuraFont.display())
                        .foregroundColor(AuraColor.ink)
                    Text("First meeting 9:00 · 25 min commute")
                        .font(AuraFont.caption())
                        .foregroundColor(AuraColor.slate)
                }
            }
            .padding(.horizontal, 20)

            Spacer()

            PrimaryButton(title: "Go to Today", action: onContinue)
                .padding(.horizontal, 20)
                .padding(.bottom, 32)
        }
    }
}

#Preview {
    FirstValueView(onContinue: {})
}
