import SwiftUI

struct TodayView: View {
    @StateObject private var viewModel = TodayViewModel()
    @State private var showingOverrideSheet = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: AuraSpacing.lg) {
                    wakeTimeCard
                    todayEventsSection
                    attentionSection
                }
                .padding(.horizontal, 20)
                .padding(.top, 8)
                .padding(.bottom, 24)
            }
            .background(AuraColor.surfaceTint.ignoresSafeArea())
            .navigationTitle("")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Good evening").font(AuraFont.title()).foregroundColor(AuraColor.ink)
                        Text(Date().formatted(.dateTime.weekday(.wide).day().month(.wide)))
                            .font(AuraFont.caption()).foregroundColor(AuraColor.slate)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: SettingsView()) {
                        Image(systemName: "gearshape.fill")
                            .foregroundColor(AuraColor.accent)
                            .padding(8)
                            .background(Circle().fill(AuraColor.suggestionBackground))
                    }
                }
            }
        }
        .task { await viewModel.load() }
        .sheet(isPresented: $showingOverrideSheet) {
            ManualWakeTimeSheet { newDate in
                Task { await viewModel.setOverride(newDate) }
            }
        }
    }

    private var wakeTimeCard: some View {
        AuraCard {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    SectionLabel(text: "Wake-up · tomorrow")
                    if let plan = viewModel.wakeTimePlan {
                        Text(plan.computedWakeAt.shortTimeString)
                            .font(AuraFont.display())
                            .foregroundColor(AuraColor.ink)
                        Text(plan.reasonText)
                            .font(AuraFont.caption())
                            .foregroundColor(AuraColor.slate)
                    } else {
                        ProgressView()
                    }
                }
                Spacer()
                Button { showingOverrideSheet = true } label: {
                    Image(systemName: "pencil")
                        .foregroundColor(Color(hex: "B4AFC7"))
                }
            }
        }
    }

    private var todayEventsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            SectionLabel(text: "Today")
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(viewModel.todayEvents) { event in
                        EventChipView(event: event)
                    }
                }
            }
        }
    }

    private var attentionSection: some View {
        AuraCard {
            SectionLabel(text: "Needs your attention")
            if viewModel.attentionMessages.isEmpty && viewModel.todos.isEmpty {
                Text("You're all caught up.")
                    .font(AuraFont.caption())
                    .foregroundColor(AuraColor.slate)
                    .padding(.vertical, 8)
            } else {
                ForEach(viewModel.attentionMessages) { message in
                    AttentionRow(
                        icon: message.senderInitial,
                        title: "Reply drafted for \(message.senderName)",
                        subtitle: message.subject,
                        badgeText: "Review",
                        badgeStyle: .neutral
                    )
                }
                ForEach(viewModel.todos) { todo in
                    AttentionRow(
                        icon: "📄",
                        title: todo.title,
                        subtitle: todo.source == .mailExtraction ? "To-do from email" : "To-do",
                        badgeText: todo.dueAt.map { $0.relativeDueString } ?? "",
                        badgeStyle: badgeStyle(for: todo.dueAt)
                    )
                }
            }
        }
    }

    private func badgeStyle(for dueDate: Date?) -> BadgeStyle {
        guard let dueDate else { return .neutral }
        let days = Calendar.current.dateComponents([.day], from: Date(), to: dueDate).day ?? 99
        if days <= 0 { return .success }
        if days <= 2 { return .warning }
        return .neutral
    }
}

private struct AttentionRow: View {
    let icon: String
    let title: String
    let subtitle: String
    let badgeText: String
    let badgeStyle: BadgeStyle

    var body: some View {
        HStack(spacing: 12) {
            Circle().fill(AuraColor.suggestionBackground).frame(width: 38, height: 38)
                .overlay(Text(icon).font(.system(size: 15, weight: .bold)).foregroundColor(AuraColor.accent))
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(AuraFont.bodyBold()).foregroundColor(AuraColor.ink)
                Text(subtitle).font(AuraFont.caption()).foregroundColor(AuraColor.slate)
            }
            Spacer()
            if !badgeText.isEmpty {
                StatusBadge(text: badgeText, style: badgeStyle)
            }
        }
        .padding(.vertical, 8)
    }
}

private struct ManualWakeTimeSheet: View {
    let onSave: (Date) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var selectedDate = Date.at(7, 10)

    var body: some View {
        NavigationStack {
            VStack {
                DatePicker("Wake-up time", selection: $selectedDate, displayedComponents: .hourAndMinute)
                    .datePickerStyle(.wheel)
                    .padding()
                Text("This applies to tomorrow only. Aura's automatic calculation resumes the day after.")
                    .font(AuraFont.caption())
                    .foregroundColor(AuraColor.slate)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                Spacer()
                PrimaryButton(title: "Save for tomorrow") {
                    onSave(selectedDate)
                    dismiss()
                }
                .padding()
            }
            .navigationTitle("Set wake-up time")
            .navigationBarTitleDisplayMode(.inline)
        }
        .presentationDetents([.medium])
    }
}

#Preview {
    TodayView()
}
