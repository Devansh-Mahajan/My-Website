import SwiftUI

/// The two-tab app shell described in Section 5 (Information Architecture)
/// of the build documentation. No side nav rail in the MVP — that returns
/// once Banking/Parking/Clothing modules justify the extra structure.
struct RootView: View {
    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = .white
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }

    var body: some View {
        TabView {
            TodayView()
                .tabItem { Label("Today", systemImage: "circle.lefthalf.filled") }

            InboxListView()
                .tabItem { Label("Inbox", systemImage: "envelope.fill") }
        }
        .tint(AuraColor.accent)
    }
}

#Preview {
    RootView()
}
