import Foundation

// MARK: - Protocols
//
// These protocols are the seam between UI and data. The MVP ships with
// Mock implementations backed by sample data so the app is fully runnable
// and testable on day one. A future engineer implements `Live*` versions
// of these same protocols against the real backend (see Section 16, API
// Design, in the build documentation) without touching any View code.

protocol MailServiceProtocol {
    func fetchMessages() async throws -> [EmailMessage]
    func sendReply(for messageID: UUID, text: String) async throws
}

protocol CalendarServiceProtocol {
    func fetchTodayEvents() async throws -> [CalendarEvent]
    func fetchFreeSlots(nextDays: Int) async throws -> [TimeSlotOption]
}

protocol WakeTimeServiceProtocol {
    func fetchTomorrowPlan() async throws -> WakeTimePlan
    func setManualOverride(_ date: Date) async throws
}

protocol TodoServiceProtocol {
    func fetchTodos() async throws -> [TodoItem]
}

// MARK: - Mock implementations

final class MockMailService: MailServiceProtocol {
    func fetchMessages() async throws -> [EmailMessage] {
        try await Task.sleep(nanoseconds: 300_000_000)
        return EmailMessage.sampleData
    }

    func sendReply(for messageID: UUID, text: String) async throws {
        try await Task.sleep(nanoseconds: 400_000_000)
        // In the live implementation this calls the provider's send API
        // (Gmail messages.send / Graph sendMail) so the reply appears in
        // the user's own Sent folder.
    }
}

final class MockCalendarService: CalendarServiceProtocol {
    func fetchTodayEvents() async throws -> [CalendarEvent] {
        try await Task.sleep(nanoseconds: 200_000_000)
        return CalendarEvent.sampleToday
    }

    func fetchFreeSlots(nextDays: Int) async throws -> [TimeSlotOption] {
        try await Task.sleep(nanoseconds: 200_000_000)
        return [
            TimeSlotOption(displayText: "Tue 14:00", isRecommended: true),
            TimeSlotOption(displayText: "Wed 10:00"),
            TimeSlotOption(displayText: "Wed 15:30"),
        ]
    }
}

final class MockWakeTimeService: WakeTimeServiceProtocol {
    private var override: Date?

    func fetchTomorrowPlan() async throws -> WakeTimePlan {
        try await Task.sleep(nanoseconds: 200_000_000)
        let firstEventStart = Date.at(9, 0)
        let computed = WakeTimeCalculator.calculateWakeTime(
            firstEventStart: firstEventStart,
            travelMinutes: 25,
            prepMinutes: 30
        )
        return WakeTimePlan(
            computedWakeAt: override ?? computed,
            firstEventTitle: "Team standup",
            commuteMinutes: 25,
            isManualOverride: override != nil
        )
    }

    func setManualOverride(_ date: Date) async throws {
        override = date
    }
}

final class MockTodoService: TodoServiceProtocol {
    func fetchTodos() async throws -> [TodoItem] {
        try await Task.sleep(nanoseconds: 150_000_000)
        return TodoItem.sampleData
    }
}
