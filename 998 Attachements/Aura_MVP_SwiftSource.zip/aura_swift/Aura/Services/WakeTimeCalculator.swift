import Foundation

/// Pure calculation logic for the wake-up time, isolated from networking
/// and UI so it can be unit tested directly (see Section 23, QA & Testing
/// Strategy: "this is a pure function and should be the most rigorously
/// tested piece of logic in the app").
///
/// Formula (Section 19 of the build documentation):
/// wake_at = event_start − travel_time − prep_time − fixed_buffer
enum WakeTimeCalculator {
    static let defaultBufferMinutes = 5

    static func calculateWakeTime(
        firstEventStart: Date,
        travelMinutes: Int,
        prepMinutes: Int,
        bufferMinutes: Int = defaultBufferMinutes
    ) -> Date {
        let totalMinutesBefore = travelMinutes + prepMinutes + bufferMinutes
        return Calendar.current.date(byAdding: .minute, value: -totalMinutesBefore, to: firstEventStart) ?? firstEventStart
    }

    /// Whether a newly computed wake time differs enough from the
    /// previous plan to justify a fresh push notification (Section 19:
    /// "only surface a new push notification if the change is significant,
    /// e.g. more than 10 minutes, to avoid notification fatigue").
    static func shouldNotify(previousWakeTime: Date?, newWakeTime: Date, thresholdMinutes: Int = 10) -> Bool {
        guard let previousWakeTime else { return true }
        let diffMinutes = abs(Calendar.current.dateComponents([.minute], from: previousWakeTime, to: newWakeTime).minute ?? 0)
        return diffMinutes >= thresholdMinutes
    }
}
