import SwiftUI

/// Aura's design-token colors, matching the palette defined in the
/// Aura UI/UX & Build Documentation (Section 3.1).
enum AuraColor {
    static let accent = Color(hex: "5B4B8A")        // Aura Violet — primary actions, active tab
    static let accentLight = Color(hex: "8A7CC0")    // Secondary accent
    static let ink = Color(hex: "1F1B2E")            // Primary text
    static let slate = Color(hex: "6B6B76")          // Secondary / meta text
    static let surfaceTint = Color(hex: "F7F5FB")    // Screen background
    static let cardBackground = Color.white
    static let cardBorder = Color(hex: "E8E5F2")
    static let suggestionBackground = Color(hex: "F5F2FB")
    static let suggestionBorder = Color(hex: "DCD4EF")

    static let success = Color(hex: "3E8E5A")
    static let warning = Color(hex: "C97A2B")
    static let neutralBadgeBackground = Color(hex: "F0EEF7")
    static let warningBadgeBackground = Color(hex: "FBF0E4")
    static let successBadgeBackground = Color(hex: "E8F3EC")
}

extension Color {
    /// Convenience initializer so design-token hex values can be used directly,
    /// matching the palette hex codes from the design documentation.
    init(hex: String) {
        let scanner = Scanner(string: hex)
        var rgbValue: UInt64 = 0
        scanner.scanHexInt64(&rgbValue)

        let r = Double((rgbValue & 0xFF0000) >> 16) / 255.0
        let g = Double((rgbValue & 0x00FF00) >> 8) / 255.0
        let b = Double(rgbValue & 0x0000FF) / 255.0

        self.init(red: r, green: g, blue: b)
    }
}
