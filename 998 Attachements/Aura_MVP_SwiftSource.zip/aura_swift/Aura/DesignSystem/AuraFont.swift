import SwiftUI

/// Typography scale from the design documentation (Section 3.2).
/// All styles use Dynamic Type-friendly relative sizing.
enum AuraFont {
    static func display() -> Font {
        .system(size: 52, weight: .bold, design: .default)
    }
    static func title() -> Font {
        .system(size: 22, weight: .semibold)
    }
    static func body() -> Font {
        .system(size: 17, weight: .regular)
    }
    static func bodyBold() -> Font {
        .system(size: 15, weight: .semibold)
    }
    static func caption() -> Font {
        .system(size: 13, weight: .regular)
    }
    static func label() -> Font {
        .system(size: 11, weight: .bold)
    }
}

enum AuraSpacing {
    static let xs: CGFloat = 8
    static let sm: CGFloat = 12
    static let md: CGFloat = 16
    static let lg: CGFloat = 24
    static let xl: CGFloat = 32

    static let cardRadius: CGFloat = 20
    static let buttonRadius: CGFloat = 14
    static let chipRadius: CGFloat = 20
}
