import SwiftUI

/// Tappable pill showing a proposed meeting time. Selected state matches
/// the "Default / Selected / Disabled" states from the component library.
struct TimeSlotChip: View {
    let title: String
    var isSelected: Bool = false
    var isDisabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(AuraFont.bodyBold())
                .foregroundColor(isSelected ? .white : AuraColor.accent)
                .padding(.horizontal, 14)
                .padding(.vertical, 8)
                .background(isSelected ? AuraColor.accent : Color.white)
                .clipShape(Capsule())
                .overlay(
                    Capsule().stroke(AuraColor.accent, lineWidth: isSelected ? 0 : 1.5)
                )
                .opacity(isDisabled ? 0.4 : 1)
        }
        .disabled(isDisabled)
    }
}

enum BadgeStyle {
    case neutral, warning, success

    var background: Color {
        switch self {
        case .neutral: return AuraColor.neutralBadgeBackground
        case .warning: return AuraColor.warningBadgeBackground
        case .success: return AuraColor.successBadgeBackground
        }
    }
    var foreground: Color {
        switch self {
        case .neutral: return AuraColor.slate
        case .warning: return AuraColor.warning
        case .success: return AuraColor.success
        }
    }
}

/// Small rounded status badge — used for deadlines, review states, etc.
/// Color usage is deliberate: neutral for routine, warning for approaching
/// deadlines, success for same-day/confirmed. Red is reserved for genuinely
/// overdue items and is not part of this default set (see design docs 11).
struct StatusBadge: View {
    let text: String
    let style: BadgeStyle

    var body: some View {
        Text(text)
            .font(AuraFont.label())
            .foregroundColor(style.foreground)
            .padding(.horizontal, 10)
            .padding(.vertical, 4)
            .background(style.background)
            .clipShape(Capsule())
    }
}

/// Standard soft card container used throughout the app.
struct AuraCard<Content: View>: View {
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: AuraSpacing.sm) {
            content
        }
        .padding(AuraSpacing.md)
        .background(AuraColor.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: AuraSpacing.cardRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: AuraSpacing.cardRadius, style: .continuous)
                .stroke(AuraColor.cardBorder, lineWidth: 1)
        )
        .shadow(color: AuraColor.accent.opacity(0.06), radius: 12, x: 0, y: 4)
    }
}

/// Section label used above groups of content, e.g. "NEEDS YOUR ATTENTION".
struct SectionLabel: View {
    let text: String
    var body: some View {
        Text(text.uppercased())
            .font(AuraFont.label())
            .kerning(0.8)
            .foregroundColor(AuraColor.accent)
    }
}
