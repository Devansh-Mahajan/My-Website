import SwiftUI

/// Filled violet button — used for exactly one primary action per screen
/// (Send, Connect, Approve, Get Started).
struct PrimaryButton: View {
    let title: String
    var isLoading: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ZStack {
                if isLoading {
                    ProgressView().tint(.white)
                } else {
                    Text(title)
                        .font(AuraFont.bodyBold())
                        .foregroundColor(.white)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 15)
            .background(AuraColor.accent)
            .clipShape(RoundedRectangle(cornerRadius: AuraSpacing.buttonRadius, style: .continuous))
        }
        .disabled(isLoading)
        .accessibilityLabel(title)
    }
}

/// Outline violet button — used for secondary actions (Edit, Dismiss).
struct SecondaryButton: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(AuraFont.bodyBold())
                .foregroundColor(AuraColor.accent)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .overlay(
                    RoundedRectangle(cornerRadius: AuraSpacing.buttonRadius, style: .continuous)
                        .stroke(AuraColor.accent, lineWidth: 1.5)
                )
        }
        .accessibilityLabel(title)
    }
}

/// Low-emphasis text-only button (e.g. "Skip for now").
struct TextLinkButton: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(AuraFont.caption())
                .fontWeight(.semibold)
                .foregroundColor(AuraColor.slate)
        }
    }
}
