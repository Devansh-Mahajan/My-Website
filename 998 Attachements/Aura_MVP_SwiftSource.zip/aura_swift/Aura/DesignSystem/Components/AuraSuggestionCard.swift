import SwiftUI

/// The tinted, left-bordered card used for any AI-generated content.
/// Every Aura suggestion MUST be wrapped in this component — never shown
/// as if the user wrote it themselves. See Section 8.2 of the design docs.
struct AuraSuggestionCard<Content: View>: View {
    let label: String
    @ViewBuilder let content: Content

    init(label: String = "Aura suggests", @ViewBuilder content: () -> Content) {
        self.label = label
        self.content = content()
    }

    var body: some View {
        HStack(spacing: 0) {
            Rectangle()
                .fill(AuraColor.accent)
                .frame(width: 4)

            VStack(alignment: .leading, spacing: AuraSpacing.xs) {
                HStack(spacing: 6) {
                    Image(systemName: "sparkle")
                        .font(.system(size: 11, weight: .bold))
                    Text(label.uppercased())
                        .font(AuraFont.label())
                        .kerning(0.5)
                }
                .foregroundColor(AuraColor.accent)

                content
            }
            .padding(AuraSpacing.md)
        }
        .background(AuraColor.suggestionBackground)
        .clipShape(RoundedRectangle(cornerRadius: AuraSpacing.cardRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: AuraSpacing.cardRadius, style: .continuous)
                .stroke(AuraColor.suggestionBorder, lineWidth: 1)
        )
        .accessibilityElement(children: .combine)
        .accessibilityLabel("AI-drafted \(label.lowercased()), not yet sent")
    }
}
