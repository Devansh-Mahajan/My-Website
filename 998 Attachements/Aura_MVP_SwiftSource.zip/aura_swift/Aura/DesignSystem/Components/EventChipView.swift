import SwiftUI

/// A single event in the Today screen's horizontally scrollable calendar strip.
struct EventChipView: View {
    let event: CalendarEvent

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(event.startAt.hourMinuteString)
                .font(AuraFont.bodyBold())
                .foregroundColor(AuraColor.accent)
            Text(event.title)
                .font(AuraFont.bodyBold())
                .foregroundColor(AuraColor.ink)
                .lineLimit(2)
            if let location = event.location {
                Text(location)
                    .font(.system(size: 11))
                    .foregroundColor(AuraColor.slate)
            }
        }
        .padding(12)
        .frame(minWidth: 110, alignment: .leading)
        .background(AuraColor.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(AuraColor.cardBorder, lineWidth: 1))
    }
}
