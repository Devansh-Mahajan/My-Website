import Foundation

@MainActor
final class InboxViewModel: ObservableObject {
    @Published var messages: [EmailMessage] = []
    @Published var isLoading = false
    @Published var isSending = false

    private let mailService: MailServiceProtocol

    init(mailService: MailServiceProtocol = MockMailService()) {
        self.mailService = mailService
    }

    func load() async {
        isLoading = true
        defer { isLoading = false }
        do {
            messages = try await mailService.fetchMessages()
        } catch {
            print("InboxViewModel load error: \(error)")
        }
    }

    /// Sends the (possibly edited) reply. This is the one place in the MVP
    /// where an irreversible action happens — it must always be triggered
    /// by an explicit user tap, never automatically. See Guardrails,
    /// Section 20.3 of the build documentation.
    func sendReply(for message: EmailMessage, editedText: String) async {
        guard let index = messages.firstIndex(where: { $0.id == message.id }) else { return }
        isSending = true
        defer { isSending = false }
        do {
            try await mailService.sendReply(for: message.id, text: editedText)
            messages[index].replyStatus = .sent
        } catch {
            print("sendReply error: \(error)")
        }
    }

    func discardDraft(for message: EmailMessage) {
        guard let index = messages.firstIndex(where: { $0.id == message.id }) else { return }
        messages[index].replyStatus = .discarded
        messages[index].draftedReply = nil
    }
}
