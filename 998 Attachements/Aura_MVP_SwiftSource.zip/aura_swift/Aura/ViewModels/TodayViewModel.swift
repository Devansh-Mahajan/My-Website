import Foundation

@MainActor
final class TodayViewModel: ObservableObject {
    @Published var wakeTimePlan: WakeTimePlan?
    @Published var todayEvents: [CalendarEvent] = []
    @Published var attentionMessages: [EmailMessage] = []
    @Published var todos: [TodoItem] = []
    @Published var isLoading = false

    private let wakeTimeService: WakeTimeServiceProtocol
    private let calendarService: CalendarServiceProtocol
    private let mailService: MailServiceProtocol
    private let todoService: TodoServiceProtocol

    init(
        wakeTimeService: WakeTimeServiceProtocol = MockWakeTimeService(),
        calendarService: CalendarServiceProtocol = MockCalendarService(),
        mailService: MailServiceProtocol = MockMailService(),
        todoService: TodoServiceProtocol = MockTodoService()
    ) {
        self.wakeTimeService = wakeTimeService
        self.calendarService = calendarService
        self.mailService = mailService
        self.todoService = todoService
    }

    func load() async {
        isLoading = true
        defer { isLoading = false }
        async let plan = wakeTimeService.fetchTomorrowPlan()
        async let events = calendarService.fetchTodayEvents()
        async let messages = mailService.fetchMessages()
        async let todoItems = todoService.fetchTodos()

        do {
            wakeTimePlan = try await plan
            todayEvents = try await events
            let allMessages = try await messages
            attentionMessages = allMessages.filter { $0.replyStatus == .drafted }
            let allTodos = try await todoItems
            todos = allTodos.filter { $0.status == .open }
        } catch {
            // In production: surface a non-blocking error state per
            // Section 11 of the build documentation (specific, non-technical
            // messaging, with a retry action).
            print("TodayViewModel load error: \(error)")
        }
    }

    func setOverride(_ date: Date) async {
        try? await wakeTimeService.setManualOverride(date)
        await load()
    }
}
