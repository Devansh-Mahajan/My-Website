import Foundation

/// Sample/preview data only — mirrors the content shown in the mockups
/// from the Illustrated UI/UX Documentation, so the running app matches
/// the design reference exactly. No real user data is represented here.
extension EmailMessage {
    static let sampleData: [EmailMessage] = [
        EmailMessage(
            id: UUID(),
            senderName: "Benni Keller",
            senderInitial: "B",
            subject: "Workshop prep — can we set a time?",
            bodyPreview: "Can we find a time this week to prep the workshop deck?",
            fullBody: "Hey AN — can we find a time this week to prep the workshop deck? Let me know when you have time.",
            receivedAt: Date().addingTimeInterval(-3600 * 3),
            detectedDeadline: nil,
            detectedMeetingRequest: true,
            replyStatus: .drafted,
            draftedReply: "Hey Benni — happy to! I'd have time Tuesday 14:00, Wednesday 10:00, or Wednesday 15:30. Let me know what suits you.",
            proposedSlots: [
                TimeSlotOption(displayText: "Tue 14:00", isRecommended: true),
                TimeSlotOption(displayText: "Wed 10:00"),
                TimeSlotOption(displayText: "Wed 15:30"),
            ]
        ),
        EmailMessage(
            id: UUID(),
            senderName: "Dr. Müller Praxis",
            senderInitial: "Dr",
            subject: "Invoice for your last visit",
            bodyPreview: "Anbei senden wir Ihnen die Rechnung für Ihre letzte Behandlung.",
            fullBody: "Guten Tag, anbei senden wir Ihnen die Rechnung für Ihre letzte Behandlung. Freundliche Grüsse.",
            receivedAt: Date().addingTimeInterval(-3600 * 5),
            detectedDeadline: Date().addingTimeInterval(3600 * 24 * 2),
            detectedMeetingRequest: false,
            replyStatus: .none,
            draftedReply: nil,
            proposedSlots: []
        ),
        EmailMessage(
            id: UUID(),
            senderName: "Sarah — Turnverein",
            senderInitial: "S",
            subject: "Practice moved to Thursday",
            bodyPreview: "Quick heads up that practice this week moved to Thursday.",
            fullBody: "Quick heads up that practice this week moved to Thursday, same time.",
            receivedAt: Date().addingTimeInterval(-3600 * 20),
            detectedDeadline: nil,
            detectedMeetingRequest: false,
            replyStatus: .none,
            draftedReply: nil,
            proposedSlots: []
        ),
    ]
}

extension CalendarEvent {
    static let sampleToday: [CalendarEvent] = [
        CalendarEvent(id: UUID(), title: "Team standup", startAt: Date.at(9, 0), endAt: Date.at(9, 15), location: "Zoom", sourceCalendar: "Work"),
        CalendarEvent(id: UUID(), title: "Lunch — Dana", startAt: Date.at(12, 30), endAt: Date.at(13, 15), location: "Bahnhofstrasse", sourceCalendar: "Private"),
        CalendarEvent(id: UUID(), title: "Dentist", startAt: Date.at(16, 0), endAt: Date.at(16, 45), location: "15 min away", sourceCalendar: "Private"),
    ]
}

extension TodoItem {
    static let sampleData: [TodoItem] = [
        TodoItem(id: UUID(), title: "Send workshop files", dueAt: Date().addingTimeInterval(3600 * 24 * 2), source: .mailExtraction, status: .open),
        TodoItem(id: UUID(), title: "Confirm dentist appointment", dueAt: Date(), source: .manual, status: .open),
    ]
}

extension Date {
    static func at(_ hour: Int, _ minute: Int) -> Date {
        Calendar.current.date(bySettingHour: hour, minute: minute, second: 0, of: Date()) ?? Date()
    }

    /// e.g. "7:10"
    var shortTimeString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "H:mm"
        return formatter.string(from: self)
    }

    /// e.g. "09:00"
    var hourMinuteString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: self)
    }

    /// Relative day string used for deadline badges, e.g. "Due in 2d".
    var relativeDueString: String {
        let days = Calendar.current.dateComponents([.day], from: Date(), to: self).day ?? 0
        if days <= 0 { return "Due today" }
        if days == 1 { return "Due in 1d" }
        return "Due in \(days)d"
    }
}
