import Foundation

/// Mirrors the MessageSummary entity from the Data Model section of the
/// build documentation. Full raw bodies are fetched just-in-time from the
/// provider API in the real implementation — only this derived summary
/// is meant to persist long-term.
struct EmailMessage: Identifiable, Hashable {
    enum ReplyStatus { case none, drafted, sent, discarded }

    let id: UUID
    let senderName: String
    let senderInitial: String
    let subject: String
    let bodyPreview: String
    let fullBody: String
    let receivedAt: Date
    var detectedDeadline: Date?
    var detectedMeetingRequest: Bool
    var replyStatus: ReplyStatus
    var draftedReply: String?
    var proposedSlots: [TimeSlotOption]
}

struct TimeSlotOption: Identifiable, Hashable {
    let id = UUID()
    let displayText: String
    var isRecommended: Bool = false
}

struct CalendarEvent: Identifiable, Hashable {
    let id: UUID
    let title: String
    let startAt: Date
    let endAt: Date
    let location: String?
    let sourceCalendar: String
}

struct TodoItem: Identifiable, Hashable {
    enum Source { case manual, mailExtraction }
    enum Status { case open, done }

    let id: UUID
    var title: String
    var dueAt: Date?
    let source: Source
    var status: Status
}

struct WakeTimePlan {
    var computedWakeAt: Date
    var firstEventTitle: String
    var commuteMinutes: Int
    var isManualOverride: Bool

    var reasonText: String {
        "First event: \(firstEventTitle) · \(commuteMinutes) min commute (live traffic)"
    }
}

struct ConnectedAccount: Identifiable {
    enum Provider: String { case gmail = "Gmail", microsoft = "Outlook / Microsoft", icloudCalendar = "iCloud Calendar" }

    let id = UUID()
    let provider: Provider
    var lastSyncedAt: Date
}
