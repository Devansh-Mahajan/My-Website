import XCTest
@testable import Aura

/// Per Section 23 (QA & Testing Strategy) of the build documentation,
/// the wake-time calculation is the most rigorously tested piece of
/// logic in the app, since its correctness is the core trust promise.
final class WakeTimeCalculatorTests: XCTestCase {

    func testCalculatesWakeTimeSubtractingTravelPrepAndBuffer() {
        let calendar = Calendar.current
        let eventStart = calendar.date(bySettingHour: 9, minute: 0, second: 0, of: Date())!

        let wakeTime = WakeTimeCalculator.calculateWakeTime(
            firstEventStart: eventStart,
            travelMinutes: 25,
            prepMinutes: 30,
            bufferMinutes: 5
        )

        // 9:00 − 25 − 30 − 5 = 7:00
        let expected = calendar.date(bySettingHour: 7, minute: 0, second: 0, of: Date())!
        XCTAssertEqual(wakeTime, expected)
    }

    func testUsesDefaultBufferWhenNotSpecified() {
        let calendar = Calendar.current
        let eventStart = calendar.date(bySettingHour: 9, minute: 0, second: 0, of: Date())!

        let wakeTime = WakeTimeCalculator.calculateWakeTime(
            firstEventStart: eventStart,
            travelMinutes: 20,
            prepMinutes: 20
        )

        // 9:00 − 20 − 20 − 5 (default) = 8:15
        let expected = calendar.date(bySettingHour: 8, minute: 15, second: 0, of: Date())!
        XCTAssertEqual(wakeTime, expected)
    }

    func testShouldNotNotifyForSmallChange() {
        let base = Date()
        let small = Calendar.current.date(byAdding: .minute, value: 4, to: base)!
        XCTAssertFalse(WakeTimeCalculator.shouldNotify(previousWakeTime: base, newWakeTime: small))
    }

    func testShouldNotifyForSignificantChange() {
        let base = Date()
        let large = Calendar.current.date(byAdding: .minute, value: 15, to: base)!
        XCTAssertTrue(WakeTimeCalculator.shouldNotify(previousWakeTime: base, newWakeTime: large))
    }

    func testAlwaysNotifiesWhenNoPreviousPlanExists() {
        XCTAssertTrue(WakeTimeCalculator.shouldNotify(previousWakeTime: nil, newWakeTime: Date()))
    }
}
