# Hausaufgabe 01 – Einführung Python

| | |
|---|---|
| **online ab** | Mi 16.09.2026, nach der Vorlesung |
| **Abgabe** | Sa 19.09.2026, 23:59 – freiwillig |
| **Besprechung** | Mo 21.09.2026 in `s02_01_coding_besprechung_hausaufgabe_01` |

## Rahmen

- Freiwillig, **nicht benotet**. Anstoss für die Diskussion, kein Leistungsnachweis.
- Der Einsatz von KI-Werkzeugen ist erlaubt. Die Prüfung findet auf Papier statt –
  Sie sollten Ihre Lösung also erklären können.

## Abgedeckter Stoff

Variablen, Operatoren, print, input, einfache Entscheidungen

Baut auf: **ch02**. Es kommt nichts vor, was erst später behandelt wird.

## Inhalt

- `homework_01_einfuehrung_python.ipynb`
