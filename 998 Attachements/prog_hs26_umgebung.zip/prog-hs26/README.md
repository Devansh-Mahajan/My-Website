# Programming for Data Science & AI – HS26

HSLU Informatik · BSc AI & Machine Learning · 1. Semester

Willkommen. Dieser Ordner ist Ihre Arbeitsumgebung für das ganze Semester.

Sie haben ihn **einmalig** von ILIAS geladen. Die Unterlagen der einzelnen
Wochen kommen ebenfalls über ILIAS und werden **hier hinein** entpackt.

---

## Einmalig: einrichten

Ausführliche Anleitung mit Problembehebung: **[`jumpstart.md`](jumpstart.md)**
– dauert etwa 20 Minuten.

Die Kurzfassung:

```bash
# 1. uv installieren  (Windows: PowerShell)
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
#    Mac / Linux:
curl -LsSf https://astral.sh/uv/install.sh | sh

# 2. Terminal schliessen, neues öffnen, dann in diesem Ordner:
uv sync

# 3. Prüfen
uv run check.py
```

Danach in VS Code `00_check/check.ipynb` öffnen, als Kernel **`.venv`** wählen
und die erste Zelle ausführen. Beides grün: Sie sind startklar.

---

## Der Alltag

**Sie arbeiten in VS Code.** Ordner `prog-hs26` öffnen (Datei ▸ Zuletzt
verwendet), Notebook anklicken, oben rechts prüfen dass der Kernel `.venv`
ist – fertig. Das ist der Weg, den wir in der Vorlesung zeigen.

Im Terminal von VS Code brauchen Sie nur diese Befehle:

| Was | Befehl |
|---|---|
| Umgebung anlegen oder aktualisieren | `uv sync` |
| Umgebung prüfen | `uv run check.py` |
| Ein Skript ausführen | `uv run mein_skript.py` |
| Tests ausführen (ab SW13) | `uv run pytest` |
| Code formatieren | `uv run ruff format .` |

<!-- JupyterLab (`uv run jupyter lab`) ist installiert, wir verwenden es im
     Kurs aber nicht. Bleiben Sie bei VS Code. -->

### Eine Regel

**Kein `pip install`, kein `conda install`.** Fehlt ein Paket, sagen Sie uns
Bescheid – wir nehmen es für alle in `pyproject.toml` auf. Anleitungen im
Internet schreiben oft `pip install pandas`; in diesem Kurs heisst das
schlicht „ist schon installiert“.

### Wenn neues Material dazukommt

Die Wochenpakete laden Sie von ILIAS herunter und entpacken sie **hier hinein**.
Danach liegt neben `pyproject.toml` zum Beispiel `s03_funktionen/`.

Kommen neue Pakete dazu, sagen wir das ausdrücklich. Dann laden Sie das
aktualisierte Umgebungs-Paket von ILIAS, ersetzen damit `pyproject.toml` und
`uv.lock` und führen noch einmal `uv sync` aus.

---

## Was hier wo liegt

| Ordner / Datei | Inhalt |
|---|---|
| `jumpstart.md` | Einrichtung der Arbeitsumgebung, Problembehebung |
| `00_check/` | das Prüf-Notebook |
| `s01_…` bis `s14_…` | die Semesterwochen – kommen nach und nach von ILIAS dazu |

Syllabus, Kursinformation, Termine und das Cheatsheet finden Sie auf ILIAS
im Ordner *Organisation*.

Und in jeder Woche:

| Ordner | Bedeutung |
|---|---|
| `s03_01_coding_…` | **Montag** 15:30–17:15 – Besprechung der Hausaufgabe, betreutes Programmieren |
| `s03_02_lecture_…` | **Mittwoch** 12:50–15:10 – Vorlesung |
| `s03_homework_…` | die Hausaufgabe der Woche |

Die Vorlesungs-Notebooks stehen **vor** der Vorlesung online: Text vollständig,
Code-Zellen leer. Wer mag, tippt in der Vorlesung direkt darin mit. **Nach**
der Vorlesung kommt die ausgefüllte Fassung dazu.

### Hausaufgaben

Sie gehen nach der Mittwochs-Vorlesung online, sind am **Samstag um 23:59**
fällig und werden am Montag darauf besprochen. Sie sind **freiwillig und
nicht benotet** – sie sind der Anstoss für die Diskussion, kein
Leistungsnachweis. Der Einsatz von KI ist erlaubt; die Prüfung schreiben Sie
allerdings auf Papier, also sollten Sie Ihre Lösung auch erklären können.

Den vollständigen Fahrplan finden Sie im Syllabus auf ILIAS, Blatt
*Hausaufgaben*.

---

## Dateien im Wurzelverzeichnis

| Datei | Bedeutung |
|---|---|
| `pyproject.toml` | die Liste der Pakete, die dieser Kurs braucht |
| `uv.lock` | die exakten Versionen, die alle bekommen – generiert, nie von Hand ändern |
| `.python-version` | welches Python (aktuell 3.14) |
| `.venv/` | die installierte Umgebung. Versteckt. Löschen und `uv sync` baut sie neu |
| `check.py` | der Umgebungs-Check |
| `.vscode/` | Einstellungen, damit sich VS Code bei allen gleich verhält |

---

## Hilfe

1. [`jumpstart.md`](jumpstart.md), Abschnitt **Problembehebung** (P1 – P12)
2. ILIAS-Forum
3. Die Coding-Session am Montag – bringen Sie Ihren Laptop mit.
