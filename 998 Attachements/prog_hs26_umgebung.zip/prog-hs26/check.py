#!/usr/bin/env python3
"""Verify that the course environment is set up correctly.

    uv run check.py

The same check runs in the notebook 00_check/check.ipynb, so both the
terminal and the Jupyter kernel are covered.

Every red line names the fix; the numbers in brackets point at the
"Problembehebung" section of s00_setup/jumpstart.md.
"""

from __future__ import annotations

import os
import platform
import sys
from pathlib import Path

# --- packages the course needs ---------------------------------------
#     (import name, display name, first semester week that needs it)
REQUIRED = [
    ("ipykernel", "ipykernel", "SW01"),
    ("pandas", "pandas", "SW09"),
    ("numpy", "numpy", "SW11"),
    ("matplotlib", "matplotlib", "SW11"),
    ("seaborn", "seaborn", "SW11"),
    ("plotly", "plotly", "SW11"),
    ("openpyxl", "openpyxl", "SW09"),
    ("requests", "requests", "SW12"),
    ("bs4", "beautifulsoup4", "SW12"),
    ("lxml", "lxml", "SW12"),
    ("PIL", "pillow", "SW03"),
    ("tqdm", "tqdm", "SW03"),
    ("pytest", "pytest", "SW13"),
]

OPTIONAL = [
    ("pandas_gbq", "pandas-gbq", "uv sync --group gcp"),
    ("svglib", "svglib", "uv sync --group extra"),
]

MIN_PYTHON = (3, 12)

# Must be captured BEFORE the package imports further down: check_packages()
# imports ipykernel and would otherwise falsify this detection.
IN_NOTEBOOK = "ipykernel" in sys.modules and "IPython" in sys.modules

OK, WARN, FAIL = "✓", "!", "✗"
_problems: list[str] = []
_warnings: list[str] = []


def line(mark: str, label: str, detail: str = "") -> None:
    print("  %s  %-34s %s" % (mark, label, detail))


def fail(label: str, detail: str, hint: str) -> None:
    line(FAIL, label, detail)
    _problems.append("%s - %s" % (label, hint))


def warn(label: str, detail: str, hint: str = "") -> None:
    line(WARN, label, detail)
    if hint:
        _warnings.append("%s - %s" % (label, hint))


def project_root() -> Path | None:
    """Search upwards for the folder containing pyproject.toml."""
    for start in (Path(__file__).resolve().parent, Path.cwd().resolve()):
        here = start
        while True:
            if (here / "pyproject.toml").exists():
                return here
            if here.parent == here:
                break
            here = here.parent
    return None


# ---------------------------------------------------------------------


def check_python() -> None:
    print("\nPython")
    v = sys.version_info
    version = "%d.%d.%d" % (v.major, v.minor, v.micro)
    if v[:2] >= MIN_PYTHON:
        line(OK, "version", "%s on %s %s" % (version, platform.system(),
                                             platform.machine()))
    else:
        fail("version", "%s - too old, need >= %d.%d"
             % (version, *MIN_PYTHON),
             "run uv sync, then pick the .venv kernel")


def check_venv(root: Path | None) -> None:
    print("\nEnvironment")
    exe = Path(sys.executable)
    in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)

    if root is None:
        fail("project folder", "pyproject.toml not found",
             "cd into the course folder, see P7")
        return

    line(OK, "project folder", str(root))

    venv = (root / ".venv").resolve()
    if not venv.exists():
        fail(".venv folder", "missing", "run uv sync")
    elif not in_venv:
        fail("active Python", "%s - outside the environment" % exe,
             "start via `uv run check.py`; in the notebook pick the .venv kernel (P6)")
    elif Path(sys.prefix).resolve() == venv:
        # sys.executable may be a symlink into the uv-managed Python
        # installation - sys.prefix is what counts.
        line(OK, "active Python", str(exe))
    else:
        fail("active Python", "%s - not the course environment" % sys.prefix,
             "pick the .venv kernel in the notebook (P6/P7)")

    lock = root / "uv.lock"
    if lock.exists():
        line(OK, "uv.lock", "present - everyone gets the same versions")
    else:
        warn("uv.lock", "missing",
             "run `uv lock` once and ship the file with the package")

    pv = root / ".python-version"
    if pv.exists():
        want = pv.read_text(encoding="utf-8").strip()
        have = "%d.%d" % sys.version_info[:2]
        if have == want:
            line(OK, ".python-version", want)
        else:
            warn(".python-version", "wants %s, active is %s" % (want, have),
                 "run uv sync")


def check_packages() -> None:
    print("\nPackages")
    import importlib

    for module, name, since in REQUIRED:
        try:
            mod = importlib.import_module(module)
        except ImportError:
            fail(name, "missing (needed from %s)" % since, "run uv sync (P9)")
            continue
        version = getattr(mod, "__version__", "")
        line(OK, name, "%s  (from %s)" % (version, since) if version else "(from %s)" % since)

    for module, name, how in OPTIONAL:
        try:
            importlib.import_module(module)
            line(OK, name, "(optional)")
        except ImportError:
            line(".", "%s (optional)" % name, "not installed - %s" % how)


def check_smoke() -> None:
    print("\nSmoke test")
    try:
        import pandas as pd

        df = pd.DataFrame({"note": [5.5, 4.5, 6.0]})
        assert abs(float(df["note"].mean()) - 16.0 / 3) < 1e-9
        line(OK, "pandas", "DataFrame and mean")
    except Exception as exc:  # noqa: BLE001
        fail("pandas", str(exc)[:60], "run uv sync")

    try:
        import numpy as np

        assert int(np.arange(5).sum()) == 10
        line(OK, "numpy", "array and sum")
    except Exception as exc:  # noqa: BLE001
        fail("numpy", str(exc)[:60], "run uv sync")

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots()
        ax.plot([0, 1], [0, 1])
        plt.close(fig)
        line(OK, "matplotlib", "figure created and closed")
    except Exception as exc:  # noqa: BLE001
        fail("matplotlib", str(exc)[:60], "run uv sync")

    try:
        import sqlite3

        con = sqlite3.connect(":memory:")
        con.execute("create table t (a int)")
        con.execute("insert into t values (42)")
        assert con.execute("select a from t").fetchone()[0] == 42
        con.close()
        line(OK, "sqlite3", "in-memory database (standard library)")
    except Exception as exc:  # noqa: BLE001
        fail("sqlite3", str(exc)[:60], "check the Python installation")

    try:
        import tkinter  # noqa: F401

        line(OK, "tkinter/turtle", "available - coding projects will run")
    except Exception:  # noqa: BLE001
        warn("tkinter/turtle", "not available",
             "only needed for the turtle graphics; on Linux: "
             "sudo apt install python3-tk")


def check_kernel() -> None:
    print("\nContext")
    line(OK, "running in", "Jupyter kernel" if IN_NOTEBOOK else "terminal")
    line(OK, "working directory", os.getcwd())


# ---------------------------------------------------------------------


def main() -> int:
    print("=" * 68)
    print("  PROG HS26 - environment check")
    print("=" * 68)

    root = project_root()
    check_python()
    check_venv(root)
    check_packages()
    check_smoke()
    check_kernel()

    print("\n" + "=" * 68)
    if _problems:
        print("  %d problem(s):\n" % len(_problems))
        for p in _problems:
            print("   %s %s" % (FAIL, p))
        print("\n  The numbers (P1, P6, ...) point at the section")
        print("  \"Problembehebung\" in jumpstart.md.")
    else:
        print("  All green. The environment is ready. Welcome!")
    if _warnings:
        print("\n  Notes (not errors):\n")
        for w in _warnings:
            print("   %s %s" % (WARN, w))
    print("=" * 68)
    return 1 if _problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
